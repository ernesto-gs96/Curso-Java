package com.codigofacilito.clase03;

public class WriteOnChatException extends RuntimeException {

}
