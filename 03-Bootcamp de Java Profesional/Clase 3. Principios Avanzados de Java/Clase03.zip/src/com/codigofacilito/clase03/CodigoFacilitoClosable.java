package com.codigofacilito.clase03;

import java.io.Closeable;
import java.io.IOException;

public class CodigoFacilitoClosable implements AutoCloseable {
    public void startClase(){

    }

    @Override
    public void close() throws Exception {

    }
}
